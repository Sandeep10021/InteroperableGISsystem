package com.csre.iitb;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class loginProcess
 */

public class loginProcess extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	  public void doPost(HttpServletRequest request,HttpServletRequest response) throws ServletException, IOException{
	    	// TODO Auto-generated method stub
	    	String email=request.getParameter("name");
	    	String password=request.getParameter("password");
	    	
	    	request.getSession().setAttribute("name",email);
	    	request.getSession().setAttribute("password",password);
	    	
	    	((HttpServletResponse) response).sendRedirect("html/home.html");
		    	
	    	
	}

}
